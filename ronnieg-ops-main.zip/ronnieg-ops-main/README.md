- 👋 Hi, I’m @ronnieg-ops
- 👀 I’m interested in ... learning to code 
- 🌱 I’m currently learning ... Python
- 💞️ I’m looking to collaborate on ... Learning to Code
- 📫 How to reach me ... This is the Place

<!---
ronnieg-ops/ronnieg-ops is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
